<?php

return [
	'Administration', 'Construction Industry', 'Education', 'Finance', 'Health Care', 'Hotels and Restaurants', 'Industry / Manufacturing', 'Power Industry', 'Technologies', 'Trade', 'Transport & Logistics', 'Uniformed Services', 'Ministry', 'Chancellery', 'Voivodeship Office', 'Marshal Office', 'District', 'City/Township/District', 'Social Welfare Centre', 'Water and Sewerage Company', 'Voivodeship Job Centre', 'District Job Center', 'Court of justice', 'Attorney General\'s Office', 'Other', 'Developers', 'Real Estate', 'Primary Schools', 'High Schools', 'Banking', 'Capital Market', 'Financial Services', 'Investments', 'Insurance', 'Retail', 'Wholesale', 'Resale', 'Automotive', 'Plastics', 'Chamical', 'Raw material', 'Fuel', 'Wood and paper', 'Electromechanical', 'Pharmaceutical', 'Building Materials', 'Metal', 'Light', 'Food industry', 'Recycling', 'Army', 'Police', 'Information Technology', 'Telecommunication', 'Media',
];
